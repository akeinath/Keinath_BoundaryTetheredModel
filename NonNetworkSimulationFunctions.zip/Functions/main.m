% 
scales = 20:5:135;
orientation = -7.5;

av = nan(30,31,length(scales));
for scale = 20:5:135
    tic
    tmp = simGridRescaling(scale,orientation);
    av(:,:,scale==scales) = tmp;
    toc
    
    figure(1)
    set(gcf,'position',[50 50 500 400])
    imagesc(permute(nanmean(av(:,:,1:end),1),[3 2 1]))
    set(gca,'ydir','normal','ytick',[1:4:24],'yticklabel',scales([1:4:24]),...
        'xtick',[1:5:31],'xticklabel',[-75:25:75]);
    colormap jet
    caxis([-1.1 1.1])
    colorbar
    drawnow
end

% save('nonNet','av')

examples = [30 45 60 90 120];
doPlot = repmat({[]},[1 7]);
for ex = examples
    [a b] = simGridRescaling_ForExamples(ex,orientation);
    b{4} = a;
    for i = 1:length(b)
        doPlot{i} = cat(3,doPlot{i},b{i});
    end
end

plotMorphedMaps(doPlot,[3./6 4./6 5./6 1 7./6 8./6 9./6],[1 1 1 1 1 1 1],'Plots/Examples')