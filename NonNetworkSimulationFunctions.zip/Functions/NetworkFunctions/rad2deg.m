function d = rad2deg(r)
    d = (r./(2.*pi)).*360;
end