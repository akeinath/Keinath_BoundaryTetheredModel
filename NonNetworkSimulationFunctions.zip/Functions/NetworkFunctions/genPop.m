function p = genPop()
    p.mods = [];
    p.nPerMod = [];
    p.topography = [];
    p.input = [];
    p.tc = [];
    p.thresh = [];
    p.properties = [];
    p.store = [];
end