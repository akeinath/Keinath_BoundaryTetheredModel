function [act borderSpikes] = borderAct2(net,path)

end