function [best bestPop] = bestFitMorph(refMap,allMaps,xMorph,yMorph)

    %%% Range to search for fit
    
    xr = [round(length(refMap(:,1,1)).*min(xMorph)):1:round(length(refMap(:,1,1)).*max(xMorph))];
    yr = [round(length(refMap(1,:,1)).*min(yMorph)):1:round(length(refMap(1,:,1)).*max(yMorph))];
    driftAllowance = 5; % Number of pixel shifts tested to account for drift
    
%     best = nan(length(allMaps(1,1,:)),2);
    
    %%% Best Fit Stretch for Individual Maps
    parfor k = 1:length(allMaps(1,1,:))
        tmpA = allMaps(:,:,k);
        tmpBest = nan(length(xr),length(yr));
        for xi = xr
            for yi = yr
                reR = imresize(refMap(:,:,k),[xi yi]);
                
                
                tmpR2 = reR(1:min(length(tmpA(:,1)),length(reR(:,1))),...
                    1:min(length(tmpA(1,:)),length(reR(1,:))));
                
                tmpA2 = tmpA(1:min(length(tmpA(:,1)),length(reR(:,1))),...
                    1:min(length(tmpA(1,:)),length(reR(1,:))));
                
                tmpA3 = tmpA(end-min(length(tmpA(:,1)),length(reR(:,1)))+1:end,...
                    end-min(length(tmpA(1,:)),length(reR(1,:)))+1:end);
                
                tmpBest(xi==xr,yi==yr) = max([corr(tmpR2(:),tmpA2(:)) corr(tmpR2(:),tmpA3(:))]);
            end
        end
        
        [x y] = find(max(max(tmpBest))==tmpBest);
        best(k,:) = [mean(xr(x))./length(refMap(:,1,1)) mean(yr(y))./length(refMap(1,:,1))].*100;
    end
%     
    %%% Best Fit Stretch for Individual Maps
    tmpBest = nan(length(xr),length(yr));
    for xi = xr
        for yi = yr
            reR = nan([xi yi length(refMap(1,1,:))]);
            for k = 1:length(refMap(1,1,:))
                reR(:,:,k) = imresize(refMap(:,:,k),[xi yi]);
            end
            

            tmpR2 = reR(1:min(length(allMaps(:,1,1)),length(reR(:,1,1))),...
                1:min(length(allMaps(1,:,1)),length(reR(1,:,1))),:);
            
            % Bottom Aligned
            tmpA2 = allMaps(1:min(length(allMaps(:,1,1)),length(reR(:,1,1))),...
                1:min(length(allMaps(1,:,1)),length(reR(1,:,1))),:);
            
            % Top Aligned
            tmpA3 = allMaps(end-min(length(allMaps(:,1,1)),length(reR(:,1,1)))+1:end,...
                end-min(length(allMaps(1,:,1)),length(reR(1,:,1)))+1:end,:);
            
            % Center Aligned
            
%             cVals = nan(driftAllowance.*2-1,driftAllowance.*2-1,2);
            for dx = -driftAllowance:driftAllowance
                for dy = -driftAllowance:driftAllowance
                    driftR2 = tmpR2(max(dx+1,1):min(length(tmpR2(:,1,1))+dx,length(tmpR2(:,1,1))),...
                        max(dy+1,1):min(length(tmpR2(1,:,1))+dy,length(tmpR2(1,:,1))),:);

                    driftA2 = tmpA2(max(-dx+1,1):min(length(tmpR2(:,1,1))-dx,length(tmpR2(:,1,1))),...
                        max(-dy+1,1):min(length(tmpR2(1,:,1))-dy,length(tmpR2(1,:,1))),:);

                    driftA3 = tmpA3(max(-dx+1,1):min(length(tmpR2(:,1,1))-dx,length(tmpR2(:,1,1))),...
                        max(-dy+1,1):min(length(tmpR2(1,:,1))-dy,length(tmpR2(1,:,1))),:);

                    cVals(dx==-driftAllowance:driftAllowance,...
                        dy==-driftAllowance:driftAllowance,:) = ...
                        [corr(driftR2(:),driftA2(:)) corr(driftR2(:),driftA3(:))];
                end
            end
            
            tmpBest(xi==xr,yi==yr) = max(cVals(:));
        end
    end

    [x y] = find(max(max(tmpBest))==tmpBest);
    bestPop = [mean(xr(x))./length(refMap(:,1,1)) mean(yr(y))./length(refMap(1,:,1))].*100;
end