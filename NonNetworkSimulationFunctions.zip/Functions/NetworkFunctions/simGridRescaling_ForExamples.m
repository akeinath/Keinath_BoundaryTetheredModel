function [familiar_map rescaled_map] = simGridRescaling_ForExamples(scale,orientation)
    numCells = 1;
    BIN_SIZE = 2.5; % cm 2 pixel conversion bin size
    ENVIRONMENT_SIZE = [150 150]; % Familiar environment size in cm
    phase = nan(2,numCells);
    familiar_map = nan([ceil(ENVIRONMENT_SIZE./BIN_SIZE)+1 numCells]);
    familiar_extended = nan([61 501 2 numCells]);
    for k = 1:numCells
        phase(:,k) = rand(2,1).*scale;
        familiar_map(:,:,k) = mkGrid(scale./BIN_SIZE,deg2rad(orientation),phase(1,k)./BIN_SIZE,phase(2,k)./BIN_SIZE,ceil(ENVIRONMENT_SIZE./BIN_SIZE));
        
        [a b] = fitGrid(imrotate(familiar_map(:,:,k),180),[scale./BIN_SIZE 0 0 0; scale 120 ...
            scale.*2./BIN_SIZE scale.*2./BIN_SIZE]);
        
        familiar_extended(:,:,1,k) = mkGrid(scale./BIN_SIZE,deg2rad(orientation),phase(1,k)./BIN_SIZE,phase(2,k)./BIN_SIZE,[500 60]);
        familiar_extended(:,:,2,k) = mkGrid(scale./BIN_SIZE,deg2rad(orientation),a(3),a(4),[500 60]);
        familiar_extended(:,:,2,k) = imrotate(familiar_extended(:,:,2,k),180);

    end
    
    newSizes = [31:10:91];
    vals = nan(numCells,length(newSizes));
    rescaled_map = repmat({[]},[1 length(newSizes)]);
    for newSize = newSizes
        [x y] = meshgrid(-(newSize-1)./2:(newSize-1)./2,-30:30);
%         x = x.^2;
        x = (x-min(x(:)))./(2.*max(x(:)));
        samp = cat(3,fliplr(x),nan(size(x)),...
            x,nan(size(x)));
        for k = 1:numCells
            rescaled_map{newSize==newSizes} = ...
                predictMap(familiar_extended(:,:,:,k),[61 newSize],samp);
        end
    end
end