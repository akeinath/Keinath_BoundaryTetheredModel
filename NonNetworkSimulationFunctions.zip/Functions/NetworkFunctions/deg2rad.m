function r = deg2rad(d)
    r = d.*2.*pi./360;
end