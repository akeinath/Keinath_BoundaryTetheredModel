function Krupic_OKeefe_2015(isSpiking,withBorderInput)
    if nargin<1
        isSpiking=true;
    end
    if nargin<2
        withBorderInput=true;
    end
    clc
    
    folderPath = ['Krupic_OKeefe_2015'];
    if isSpiking
        folderPath = [folderPath '/Spiking' ];
    else
        folderPath = [folderPath '/Rate' ];
    end
    
    if withBorderInput
        folderPath = [folderPath '/WithBorders' ];
    else
        folderPath = [folderPath '/WithoutBorders' ];
    end
    
    
    % Overall Simulation Parameters
    p.spiking = isSpiking;
    p.sims = 1; % How many consecutive sims of exploration (each N seconds defined by path length)
    p.ts = 0.001; % timestep in seconds 0.0005 1ms?
    p.doPlot = false; % Generate Plots During Simulation
    p.forCluster = true; % Cease all plot generation and final plots if true.
    p.overwrite = true; % 

    % Path Parameters 
    p.path.type = 'open'; % Define type of environment (linear or open). If linear, make x the long dimensions

    % Border Cell Network Parameters
    p.pop(1) = params('border');
    p.pop(2) = params('grid');
    p.pop(3) = params('place');
    p.specific = params('specific');

    % Connectivity
    
    if withBorderInput
        p.link(1,2) = params('b2g');
    end
    p.link(2,2) = params('g2g');
    % 
    % p.link(1,3) = params('b2p');
%     p.link(2,3) = params('g2p');
%     p.link(3,3) = params('p2p');

    % p.link(3,2) = params('p2g');

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%% Simulations %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    p.folder = [folderPath '/Test/mx_1_my_1'];
    p.sims = 4;
    p.path.length = 900; % Length in Seconds of each path
    p.path.boundary.line = bsxfun(@minus,[0 0 1 0; 0 0 0 1; 1 0 1 1; 0 1 1 1],[.5 .5 .5 .5]).*90;
    p.path.boundary.ellipse = [];
    p.path.init = [0 0];
    precompute(p); % Precompute Paths and Border Activations for the sims
    runSims(p,[],true);

    trainedNet = load(['First_Round_Data_InPaper/MatlabData/Nets/' folderPath '/Test/mx_1_my_1']);
    p.folder = [folderPath '/Test/mx_2.1_my_1'];
    p.sims = 1;
    p.path.length = 2400; % Length in Seconds of each path || Usually 40min, trying 20min to match study!
    p.path.boundary.line = bsxfun(@minus,[0 0 0 0.2; 0 0 1.9 -0.35; 0 0.2 1.9 0.55; 1.9 0.55 1.9 -0.35],...
        [1.9./2 0.1 1.9./2 0.1]).*100;
    precompute(p); % Precompute Paths and Border Activ1.8675ations for the sims
    runSims(p,trainedNet,false);

    if ~p.forCluster
        all = getMapsFromNets(['First_Round_Data_InPaper/MatlabData/Nets/' folderPath '/Test']);
        
        plotMorphedMaps(all.maps.complete.grid,[1 1.9./0.9],[1 1],[folderPath])
        plotMorphedSpikes(all,[folderPath '/Summary'])
        plotNetMaps(net,[folderPath '/Trapazoid'],1)
        
        plotTrapGridDeformation(bM(2),folderPath)
        plotSplitMapACorr([{all.maps.complete.grid{2}(:,:,1:60)}; {all.maps.complete.grid{1}(:,:,1:60)}],[folderPath]);
        plotSplitMapFieldSize([{all.maps.complete.grid{2}(:,:,1:60)}; {all.maps.complete.grid{1}(:,:,1:60)}],[folderPath]);
    end
end



































