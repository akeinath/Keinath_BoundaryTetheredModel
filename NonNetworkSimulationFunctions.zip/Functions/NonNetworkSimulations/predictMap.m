function dm = predictMap(m,ensize,bmWeights)
    bm = nan([ensize 4]);
    bm(:,:,1) = m(:,1:min(ensize(2)),1);
    bm(:,:,3) = m(:,end-ensize(2)+1:end,2);

    dm = nansum(bm.* (bmWeights./repmat(nansum(bmWeights,3),[1 1 4])),3);
end

%%%%%%%%%%% SimpleWeighting

% [x2 y2] = meshgrid([1:ensize(2)],[1:ensize(1)]);
%         samp = cat(3,x2,y2,imrotate(x2,180),imrotate(y2,180));
%         samp = samp./max(samp(:));
%         samp = 1-samp;
%         
%         samp = samp .* repmat(cat(3,length(samp(:,1,1)),length(samp(1,:,1)),...
%             length(samp(:,1,1)),length(samp(1,:,1)))./max(size(samp(:,:,1))),[length(samp(:,1,1)) length(samp(1,:,1)) 1]);
%         samp = samp./repmat(nansum(samp,3),[1 1 4]);

%%%%%%%%%%%% COMPLEX

% [x2 y2] = meshgrid([zeros(1,5) 1:ensize(2)-5],[zeros(1,5) 1:ensize(1)-5]);
% samp = cat(3,x2,y2,imrotate(x2,180),imrotate(y2,180));
% samp = samp./max(samp(:));
% samp = 1-samp;
% samp(samp~=1&repmat(any(samp==1,3),[1 1 4])) = 0;
% 
% samp = samp .* repmat(cat(3,length(samp(:,1,1)),length(samp(1,:,1)),...
%     length(samp(:,1,1)),length(samp(1,:,1)))./max(size(samp(:,:,1))),[length(samp(:,1,1)) length(samp(1,:,1)) 1]);
% samp = samp./repmat(nansum(samp,3),[1 1 4]);