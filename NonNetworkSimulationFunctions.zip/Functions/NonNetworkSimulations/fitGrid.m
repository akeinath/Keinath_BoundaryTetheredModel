function [out grid] = fitGrid(m,lims)
    options = optimset('Display','off','Algorithm','active-set');
%     lims = [20 0 0 0; 200 deg2rad(60) 200 200];
    nsims = 250;
    vals = nan(nsims,1); 
    out = nan(nsims,4);
    for sim = 1:nsims
        init = [lims(1) deg2rad(sim) 0 0];
        [out(sim,:) vals(sim)] = fmincon(@(inV)error(inV,m),init,...
            [],[],[],[],lims(1,:),lims(2,:),[],options);
    end
    [a b] = nanmin(vals);
    out = out(b,:);
    
    if nargout > 1
        grid = mkGrid(out(1),out(2),out(3),out(4),size(m)-1);
    end
end

function err = error(g,m)
    grid = mkGrid(g(1),g(2),g(3),g(4),size(m)-1);
    
%     figure(1)
%     subplot(1,2,1)
%     imagesc(grid)
%     axis equal
%     subplot(1,2,2)
%     imagesc(m)
%     axis equal
%     drawnow
    
    err = -atan(corr(grid(:),m(:)));
end